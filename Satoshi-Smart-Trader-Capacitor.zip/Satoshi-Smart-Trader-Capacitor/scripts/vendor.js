// Optional: downloads the EXACT pinned CDN dependencies into www/vendor and
// points index.html at them, so the app no longer needs jsdelivr / Google Fonts.
// Run on a machine WITH internet:  npm run vendor
// Idempotent. Backup of the original index.html goes to scripts/.backup/.
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const WWW = path.join(ROOT, 'www');
const VENDOR = path.join(WWW, 'vendor');
const FONTS = path.join(VENDOR, 'fonts');
const INDEX = path.join(WWW, 'index.html');

const SUPABASE_URL = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4';
const CHART_URL = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js';
const FONT_CSS_URL = 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap';
const UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36';

async function get(url, asText) {
  const r = await fetch(url, { headers: { 'User-Agent': UA } });
  if (!r.ok) throw new Error(`HTTP ${r.status} for ${url}`);
  return asText ? await r.text() : Buffer.from(await r.arrayBuffer());
}

(async () => {
  let html = fs.readFileSync(INDEX, 'utf8');
  if (!html.includes('cdn.jsdelivr.net') && !html.includes('fonts.googleapis.com')) {
    console.log('index.html already uses local files. Nothing to do.');
    return;
  }
  fs.mkdirSync(FONTS, { recursive: true });

  const sb = await get(SUPABASE_URL, true);
  if (sb.length < 20000 || !/supabase/i.test(sb)) throw new Error('supabase-js download looks wrong');
  fs.writeFileSync(path.join(VENDOR, 'supabase.js'), sb);

  const ch = await get(CHART_URL, true);
  if (ch.length < 20000 || !/Chart/.test(ch)) throw new Error('chart.js download looks wrong');
  fs.writeFileSync(path.join(VENDOR, 'chart.umd.min.js'), ch);

  let css = await get(FONT_CSS_URL, true);
  const urls = [...new Set([...css.matchAll(/url\((https:[^)]+)\)/g)].map(m => m[1]))];
  if (!urls.length) throw new Error('no font files found in Google Fonts CSS');
  let i = 0;
  for (const u of urls) {
    const name = `plex-${String(++i).padStart(2, '0')}.woff2`;
    fs.writeFileSync(path.join(FONTS, name), await get(u, false));
    css = css.split(u).join(name);
  }
  fs.writeFileSync(path.join(FONTS, 'fonts.css'), css);

  const bk = path.join(__dirname, '.backup');
  fs.mkdirSync(bk, { recursive: true });
  fs.writeFileSync(path.join(bk, 'index.cdn.html'), html);

  const rep = (a, b, label) => { if (!html.includes(a)) throw new Error('pattern not found: ' + label); html = html.replace(a, b); };
  rep(`<script src="${SUPABASE_URL}"></script>`, '<script src="vendor/supabase.js"></script>', 'supabase script');
  rep(`<script src="${CHART_URL}"></script>`, '<script src="vendor/chart.umd.min.js"></script>', 'chart script');
  rep('<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n', '', 'preconnect');
  rep(`<link href="${FONT_CSS_URL}" rel="stylesheet">`, '<link href="vendor/fonts/fonts.css" rel="stylesheet">', 'font link');
  rep("script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net;", "script-src 'self' 'unsafe-inline';", 'csp script');
  rep("style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;", "style-src 'self' 'unsafe-inline';", 'csp style');
  rep("font-src https://fonts.gstatic.com data:;", "font-src 'self' data:;", 'csp font');
  fs.writeFileSync(INDEX, html);
  console.log(`Done: supabase.js, chart.umd.min.js, ${urls.length} font files. index.html updated.`);
})().catch(e => { console.error('FAILED (index.html NOT modified):', e.message); process.exit(1); });
